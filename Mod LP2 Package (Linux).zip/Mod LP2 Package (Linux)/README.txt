V 2.1
MacOS/Linux:

Open Terminal and type "cd " and drag this folder into the window and press Enter.

Type "chmod u+x" and drag the lp2Setup.sh file into the Terminal window and hit Enter.

--------------------------------------USAGE---------------------------------------------

Power off your phone and hold volume DOWN and POWER until you feel the phone vibrate. 

type "./lp2Setup.sh" and hit enter. 

Enjoy! :)

Report any bugs to me at dtingley11222@gmail.com

I am not responsible for anything the happens to your phone!!! 

THIS SCRIPT IS NOT UNDER THE LICENSE (NOTICE.txt) FOUND IN THIS FOLDER! 

                @@*    .@@@     @@@              @@   *@/                                  
                 @@    @@ @@    @@  @@ @@@ (@* @@@@@ @@@@@    @@@@@@    @@ @@@@@           
                 (@@  @@   @@  @@   @@@    (@*   @@   *@/   @@     @@   @@     @@          
                  @@ @@    @@ ,@@   @@.    (@*   @@   *@/  *@@@@@@@@@@  @@     @@          
                   @@@@     @@@@    @@.    (@*   @@   *@/   @@     /@&  @@     @@          
                   #@@       @@     @@.    (@*   @@@   @@@    @@@@@@    @@     @@          
                                                                                
                                                                                
                                                                                
                                                                                
                                   @@@@@@@@@@&                                             
                                   @@       @@  @@      @@                                 
                                   @@@@@@@@@@    @@    @@    @@                            
                                   @@       @@@   @@  @@                                   
                                   @@        @@   /@@/@*                                   
                                   @@@@@@@@@@*     @@@#      @@                            
                                                   .@@                                     
                                                 @@@               



                                                                   
                        .@@@@@@@@@               #@                                        
                        .@@       @@             #@                                        
                        .@@        @@  @@    @@  #@   @@&   @@(   @@@   @@                 
                        .@@        @@  *@&  &@,  #@        @@@@   @&     @@                
                        .@@       @@    &@  @@   #@   @@     @@   @&     @@                
                        .@@@@@@@@@@      @@@@    #@   @@,  @@@@   @&     @@                
                                          @@                                               
                                        @@@                                                 
                                                                                
                                                                                
                 @@@@@@@@@@@@.@,                         @@                                
                      @@                                 @@                                
                      @@     .@,  @@@    @@   @@   ,@@(  @@   @@    @@.  @@    &@*         
                      @@     .@,  @@     @@  @@      @(  @@  @@&&&&&&@@   @@   @&          
                      @@     .@,  @@     @@  @@     /@(  @@  @@            @@ @@           
                      @@     .@,  @@     @@   @@@@@@@@(  @@   @@@&&@@@      @@@            
                                                    @@                      @@             
                                               *@@@@@@                    @@@

